package com.capgemini.salesmanagement.dao;

import java.util.List;

import com.capgemini.salesmanagement.Exception.TakeHomeException;
import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.bean.SalesBean;

public interface IProductDAO {
	
	ProductBean getProductByCode(int code) throws TakeHomeException;
	Integer buyProducts(SalesBean bean) throws TakeHomeException;
	public List<ProductBean> getAllProducts()throws TakeHomeException;

	}

