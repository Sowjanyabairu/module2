package com.capgemini.salesmanagement.service;

import java.util.List;

import com.capgemini.salesmanagement.Exception.TakeHomeException;
import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.bean.SalesBean;



public interface IProductService {
	boolean validateDetails(ProductBean patient) throws TakeHomeException;
	public ProductBean getProductBycode(int code) throws TakeHomeException;
	public List<ProductBean> getAllProducts()throws TakeHomeException;
	public Integer buyProducts(SalesBean bean) throws TakeHomeException;
}
