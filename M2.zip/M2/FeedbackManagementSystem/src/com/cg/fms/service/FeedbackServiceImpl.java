package com.cg.fms.service;

import java.util.List;

import com.cg.fms.bean.Feedback;
import com.cg.fms.bean.ParticipantEnrollment;
import com.cg.fms.dao.FeedbackDaoImpl;
import com.cg.fms.dao.IFeedbackDao;
import com.cg.fms.exception.FeedbackException;

public class FeedbackServiceImpl implements IFeedbackService {

	IFeedbackDao feedbackDao = new FeedbackDaoImpl();
	@Override
	public boolean addFeedback(Feedback feedback) throws FeedbackException {
		return feedbackDao.addFeedback(feedback);
	}

	@Override
	public List<Feedback> getFeedBack(int trainingcode) throws FeedbackException {
		return feedbackDao.getFeedBack(trainingcode);
	}

	@Override
	public List<Feedback> showFeedback() throws FeedbackException {
		List<Feedback> feedbackList=null;
		feedbackList=feedbackDao.showFeedback();
		return feedbackList;
	
	}

	@Override
	public List<Feedback> getFeedBackByDate(String feedbackdate) throws FeedbackException {
		return feedbackDao.getFeedBackByDate(feedbackdate);
		
	}

	@Override
	public List<ParticipantEnrollment> fetchTrainingCode(int participantId)
			throws FeedbackException {
		return feedbackDao.fetchTrainingCode(participantId);
	}

	
}
