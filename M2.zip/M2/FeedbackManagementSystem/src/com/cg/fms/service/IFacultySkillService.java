package com.cg.fms.service;

import java.util.List;

import com.cg.fms.bean.FacultySkill;
import com.cg.fms.exception.FeedbackException;

public interface IFacultySkillService {

	public List<FacultySkill> showFacultySkillSet() throws FeedbackException;
}
