package com.cg.fms.util;

import static org.junit.Assert.assertEquals;

import java.sql.Connection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class DBConnectionTest {

	DBConnection dbconnection=new DBConnection();
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Initialization code before all test method");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Cleanup code after all test method");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("Initialization code before each test method");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("Cleanup code after each test method");

	}

	@Test
	public void testGetInstance() {
		    Connection connection = dbconnection.getInstance();
	        assertEquals(connection != null, true);
	}
	@Test
	public void testGetInstance1() {
		    Connection connection = dbconnection.getInstance();
	        assertEquals(connection == null, false);
	}
}
