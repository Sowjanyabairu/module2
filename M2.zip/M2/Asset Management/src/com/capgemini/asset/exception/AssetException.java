package com.capgemini.asset.exception;

public class AssetException extends Exception {
	private static final long serialVersionUID = 1L;
	public AssetException(){
		
	}
	public AssetException(String arg0){
		super(arg0);
	}
}
	


