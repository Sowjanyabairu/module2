package com.capgemini.contactbook.dao;

public interface QueryMapper {
	//creating query interface
	public static final String RETRIVE_ALL_QUERY="SELECT firstName,lastName,contactNo,domain,city FROM enquiry";
	public static final String VIEW_ContactBook_DETAILS_QUERY="SELECT firstName,lastName,contactNo,domain,city FROM enquiry WHERE  enquiryId=?";
		public static final String INSERT_QUERY="INSERT INTO enquiry VALUES(enquiries.NEXTVAL,?,?,?,?,?)";
		public static final String ENQUIRYID_QUERY_SEQUENCE="SELECT enquiries.CURRVAL FROM DUAL";
}
