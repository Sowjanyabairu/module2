package com.capgemini.contactbook.service;

import java.util.List;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;

//Creating contactBookService interface

public interface ContactBookService {
	
	public String addEnquiry(EnquiryBean enqry) throws ContactBookException;
	public EnquiryBean viewEnquiryDetails(String enquiryId) throws ContactBookException;
	public List<EnquiryBean> retriveAll()throws ContactBookException;
	

}
